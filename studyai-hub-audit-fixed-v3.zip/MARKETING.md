# 📣 Launch & Marketing Guide — StudyAI Hub

Everything below is free unless marked otherwise. Do them in order.

---

## PART 1 — Publish on Google (30 minutes, free)

Google won't know your site exists until you tell it. This is the single most important 30 minutes of this project.

### Step 1 — Deploy first
(If not done yet: drag the `ai-tools-directory` folder to **https://app.netlify.com/drop** — see README.md)

### Step 2 — Register with Google Search Console (free)
1. Go to **https://search.google.com/search-console**
2. Sign in with your Gmail
3. Click **"Add property"** → choose **"URL prefix"** → paste your full address:
   `https://yourname.netlify.app/`
4. Verify ownership — easiest method: **"HTML tag"**:
   - Google shows you a line like `<meta name="google-site-verification" content="abc123...">`
   - Copy ONLY the content value (`abc123...`)
   - Open `index.html`, find the `<head>` section, and add this line (replace the value):
     ```html
     <meta name="google-site-verification" content="PASTE-YOUR-CODE-HERE">
     ```
   - Re-drag the folder to Netlify, click **"Verify"** in Google
5. Inside Search Console: **Sitemaps** (left menu) → enter `sitemap.xml` → Submit

### Step 3 — Fix the sitemap/robots addresses (2 minutes)
Open `sitemap.xml` and `robots.txt` — if your Netlify address isn't `studyaihub.netlify.app`,
replace the address in both files with yours, then re-drag to Netlify.

### Step 4 — Bonus: Bing too (10 minutes, free)
**https://www.bing.com/webmasters** — it can import everything from Google Search
Console in one click. Bing + Yahoo + DuckDuckGo all use it. Do this once traffic starts.

**What to expect:** Google indexes new sites in 2–14 days. Check Search Console →
"Performance" weekly to see what people searched to find you.

---

## PART 2 — Domain (optional, do it AFTER the site gets traction)

You do NOT need a domain to start — `yourname.netlify.app` works perfectly with Google.
Buy one when the site is proven (spending money before earning = bad business).

### Where to buy (~$10–12/year for .com)
| Registrar | Note |
|---|---|
| **Cloudflare Registrar** (recommended) | Sells at cost price, no upsells |
| **Porkbun** | Cheap, friendly |
| **Namecheap** | Fine, says yes to too many add-ons — skip them |
| GoDaddy | Avoid — cheap year 1, expensive after |

💡 **Are you a student with a school email?** The **GitHub Student Developer Pack**
(https://education.github.com/pack) includes a **FREE domain for 1 year** (Namecheap .me).
Perfect for this project.

### Connect it to Netlify (10 minutes)
1. Buy the domain (e.g. `studyaihub.com`)
2. In Netlify: **Site settings → Domain management → Add custom domain**
3. Netlify shows you 2 **nameservers** (like `dns1.netlify.com`)
4. In your registrar: find **Nameserver settings** → replace with Netlify's
5. Wait 1–24 hours → Netlify gives you the HTTPS lock automatically (free)
6. Update the address in `sitemap.xml` + `robots.txt` and re-submit in Search Console

---

## PART 3 — Marketing plan (zero budget)

### The golden rule
Never spam links. Always share like a human helping humans: *"I made a free collection
of AI tools for exam prep — no signup, hope it helps"* works. "VISIT MY WEBSITE" gets you banned.

### Week 1 — Communities you already use (fastest first visitors)
- **WhatsApp/Telegram study groups**: your own class groups, exam-prep groups, college groups
- **Reddit** (careful, read each sub's rules first): r/GetStudying, r/college,
  r/productivity, r/study, r/GradSchool — post as "I built a free directory of the
  15 best AI tools for students" with genuine screenshots
- **Quora**: search "best AI tools for students" → answer 3–5 questions helpfully,
  mention your site as the full list

### Week 2 — Pinterest (secret weapon for student traffic)
Pinterest is a search engine where "study tips" content lives forever:
1. Create a free business account
2. Make 1 pin per tool in Canva (free): "The AI tool that solves math step-by-step 📸"
3. Each pin links to your site
4. 5 pins/week = steady free traffic within a month

### Week 3 — Launch boards (one-time spikes)
- **Product Hunt** (https://producthunt.com) — launch as a free resource. Directories
  do well. Tuesday–Thursday mornings (US time) are best
- **Hacker News — Show HN** (https://news.ycombinator.com) — "Show HN: A hand-reviewed
  directory of AI tools for students"

### Week 4+ — The flywheel (this is what makes money)
1. **Add 3–5 new tools weekly** → more pages → more Google traffic (this IS the SEO strategy)
2. **Email every tool you add**: "I listed [Tool] on StudyAI Hub — check your listing.
   A link back would mean a lot" → backlinks → higher Google ranking
3. Once ~1,000 visits/month: **email small AI startups** (find them on Product Hunt's
   newest listings) offering the $20 featured slot — they need student users, you have them

### What to track (free)
- **Google Search Console → Performance**: clicks, what searches find you
- **Netlify → Analytics** tab: visitors
That's it. Two numbers, checked weekly.

---

## Timeline (honest)

| When | What happens |
|---|---|
| Day 1 | Site live + submitted to Google |
| Week 1–2 | First visitors from groups/Reddit; Google indexes you |
| Month 1–2 | Pinterest + SEO start working, 200–1,000 visits/month |
| Month 2–3 | First backlinks, Google traffic grows |
| Month 3+ | First featured-listing sales become realistic |

Consistency beats everything: 30 minutes a day on Week-1/2/3 activities + weekly new
tools. Most people quit at week 3 — that's why the ones who don't, win.
