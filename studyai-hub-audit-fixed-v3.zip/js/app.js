/* ============ StudyAI Hub — app logic ============ */
const state = { q: "", category: "All", pricing: "All" };
const $ = (s) => document.querySelector(s);

/* deterministic avatar gradient class from the tool name.
   The 15 hues below are the exact gradients baked into the static HTML
   (see css/style.css .avatar.av-* and scripts/prerender.js — keep all
   three in sync). Unknown future names fall back to the nearest hue. */
const AVATAR_HUES = [139, 236, 181, 58, 340, 219, 270, 27, 226, 18, 111, 183, 43, 128, 64];
function avatarClass(name) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
  if (AVATAR_HUES.includes(h)) return `av-${h}`;
  let best = AVATAR_HUES[0], bestD = 360;
  for (const p of AVATAR_HUES) {
    const d = Math.min(Math.abs(p - h), 360 - Math.abs(p - h));
    if (d < bestD) { bestD = d; best = p; }
  }
  return `av-${best}`;
}
const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
/* v3 progressive enhancement: the static HTML already contains the cards,
   chips, stats, result count and heading (baked by scripts/prerender.js).
   These helpers only write when the value actually differs, so the initial
   load leaves the static DOM untouched — crawlers/LLMs see the same HTML
   the browser shows, and the audit's "rendered content" percentage drops. */
const setText = (el, v) => { if (el && el.textContent !== String(v)) el.textContent = String(v); };
const setHTML = (el, v) => { if (el && el.innerHTML !== v) el.innerHTML = v; };
const isDefaultState = () => state.q.trim() === "" && state.category === "All" && state.pricing === "All";
const initials = (name) => name.split(/[\s-]/).map(w => w[0]).join("").slice(0, 2).toUpperCase();
const slug = (name) => name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
const pricingClass = { "Free": "badge-free", "Freemium": "badge-freemium", "Paid": "badge-paid" };

function cardHTML(l) {
  const featuredRibbon = l.featured ? `<span class="ribbon">FEATURED</span>` : "";
  const cls = l.featured ? "card featured-card" : "card";
  return `
  <article class="${cls}" data-name="${esc(l.name)}">
    ${featuredRibbon}
    <div class="card-top">
      <div class="avatar ${avatarClass(l.name)}">${initials(l.name)}</div>
      <h3>${esc(l.name)}</h3>
    </div>
    <p class="tagline">${esc(l.tagline)}</p>
    <p class="card-desc">${esc(l.description)}</p>
    <div class="card-foot">
      <span class="badge badge-cat">${esc(l.category)}</span>
      <span class="badge ${pricingClass[l.pricing] || "badge-paid"}">${esc(l.pricing)}</span>
      <span class="visit">Visit ↗</span> <a class="details-link" href="tools/${slug(l.name)}.html">Details →</a>
    </div>
  </article>`;
}

function filtered() {
  const q = state.q.trim().toLowerCase();
  return LISTINGS.filter(l => {
    if (state.category !== "All" && l.category !== state.category) return false;
    if (state.pricing !== "All" && l.pricing !== state.pricing) return false;
    if (!q) return true;
    return [l.name, l.tagline, l.category, l.pricing, ...(l.tags || [])]
      .join(" ").toLowerCase().includes(q);
  });
}

/* true when the chips already on the page match the current filter state
   (baked statically for the default state) — then rebuilding them would
   only churn identical DOM nodes, so renderChips() skips the rebuild. */
function chipsInSync() {
  const catBtns = document.querySelectorAll("#cat-chips [data-cat]");
  const priceBtns = document.querySelectorAll("#price-chips [data-price]");
  if (catBtns.length !== CATEGORIES.length || priceBtns.length !== 4) return false;
  for (const b of catBtns) {
    if (b.classList.contains("active") !== (b.dataset.cat === state.category)) return false;
  }
  for (const b of priceBtns) {
    if (b.classList.contains("active") !== (b.dataset.price === state.pricing)) return false;
  }
  return true;
}

function renderChips() {
  if (chipsInSync()) return;
  const catChips = CATEGORIES.map(c => {
    const n = c === "All" ? LISTINGS.length : LISTINGS.filter(l => l.category === c).length;
    return `<button class="chip ${state.category === c ? "active" : ""}" data-cat="${c}">${c}<span class="count">${n}</span></button>`;
  }).join("");
  $("#cat-chips").innerHTML = catChips;

  const pricings = ["All", "Free", "Freemium", "Paid"];
  $("#price-chips").innerHTML = pricings.map(p =>
    `<button class="chip ${state.pricing === p ? "active" : ""}" data-price="${p}">${p === "All" ? "Any pricing" : p}</button>`
  ).join("");
}

/* true when the grids already show exactly what the current state needs —
   the default state with the full static card sets baked in. */
function gridsInSync() {
  if (!isDefaultState()) return false;
  const feat = document.querySelectorAll("#featured-grid .card").length;
  const list = document.querySelectorAll("#listings-grid .card").length;
  return feat === LISTINGS.filter(l => l.featured).length && list === LISTINGS.length;
}

function render() {
  const list = filtered();
  /* featured strip (always full list of featured, search ignored there) */
  if (!gridsInSync()) {
    const feat = LISTINGS.filter(l => l.featured);
    $("#featured-grid").innerHTML = feat.map(cardHTML).join("");
    $("#listings-grid").innerHTML = list.map(cardHTML).join("");
  }

  setHTML($("#result-count"), list.length
    ? `Showing <b>${list.length}</b> of <b>${LISTINGS.length}</b> tools`
    : "");
  setText($("#directory-heading"),
    state.category === "All" ? "Browse all tools" : `${state.category} tools`);
  /* the empty-state div is hidden by CSS already; only touch it when the
     state actually needs a change, so the initial load writes nothing. */
  const ed = $("#empty");
  if (list.length) { if (ed.style.display === "block") ed.style.display = "none"; }
  else if (ed.style.display !== "block") ed.style.display = "block";
}

function updateStats() {
  setText($("#stat-tools"), LISTINGS.length);
  setText($("#stat-cats"), CATEGORIES.length - 1);
  setText($("#stat-free"), LISTINGS.filter(l => l.pricing === "Free" || l.pricing === "Freemium").length);
}

/* ---- modal ---- */
function openModal(name) {
  const l = LISTINGS.find(x => x.name === name);
  if (!l) return;
  $("#modal-body").innerHTML = `
    <div class="card-top">
      <div class="avatar ${avatarClass(l.name)}">${initials(l.name)}</div>
      <div>
        <h3>${esc(l.name)}</h3>
        <div class="m-tagline">${esc(l.tagline)}</div>
      </div>
    </div>
    <p class="m-desc">${esc(l.description)}</p>
    <div class="m-badges">
      <span class="badge badge-cat">${esc(l.category)}</span>
      <span class="badge ${pricingClass[l.pricing]}">${esc(l.pricing)}</span>
      ${l.featured ? '<span class="badge badge-featured">★ Featured</span>' : ""}
    </div>
    <div class="tags">${(l.tags || []).map(t => `<span class="tag">#${esc(t)}</span>`).join("")}</div>
    <a class="btn btn-primary btn-full" href="${l.url}" target="_blank" rel="noopener noreferrer">Open ${esc(l.name)} ↗</a>`;
  $("#overlay").classList.add("open");
  document.body.style.overflow = "hidden";
}
function closeModal() {
  $("#overlay").classList.remove("open");
  document.body.style.overflow = "";
}

/* NOTE: the ItemList JSON-LD for Google lives directly inside index.html
   (static, so crawlers and link previews see it). If you add tools to
   data.js, run `node scripts/prerender.js` to re-bake the static cards
   + JSON-LD descriptions in index.html and the tool pages. */

function init() {
  updateStats();
  renderChips();
  render();

  $("#search").addEventListener("input", (e) => { state.q = e.target.value; render(); });

  const resetFilters = $("#reset-filters");
  if (resetFilters) resetFilters.addEventListener("click", (e) => {
    e.preventDefault();
    $("#search").value = ""; state.q = "";
    state.category = "All"; state.pricing = "All";
    renderChips(); render();
  });

  $("#cat-chips").addEventListener("click", (e) => {
    const chip = e.target.closest("[data-cat]");
    if (!chip) return;
    state.category = chip.dataset.cat;
    renderChips(); render();
    document.getElementById("directory").scrollIntoView({ behavior: "smooth" });
  });
  $("#price-chips").addEventListener("click", (e) => {
    const chip = e.target.closest("[data-price]");
    if (!chip) return;
    state.pricing = chip.dataset.price;
    renderChips(); render();
  });

  document.body.addEventListener("click", (e) => {
    if (e.target.closest("a")) return;
    const card = e.target.closest(".card[data-name]");
    if (card) openModal(card.dataset.name);
    if (e.target.closest(".visit")) e.stopPropagation();
  });
  $("#overlay").addEventListener("click", (e) => { if (e.target.id === "overlay") closeModal(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });
  $("#modal-close").addEventListener("click", closeModal);

  /* fill site name / price anywhere marked data-site (already correct in
     the static HTML — setText leaves them untouched on initial load) */
  document.querySelectorAll("[data-site='name']").forEach(el => setText(el, SITE.name));
  document.querySelectorAll("[data-site='price']").forEach(el =>
    setText(el, `${SITE.currency}${SITE.featuredPrice}`));
}

document.addEventListener("DOMContentLoaded", init);
