// NOTE 2026-11-22: GTM container GTM-TRF6V896 is loaded via the <head> snippet on every page (user-supplied). The loaders below stay gated for direct GA4/Pixel IDs if ever needed.
/* ============================================================
   ANALYTICS CONFIG — StudyAI Hub
   ------------------------------------------------------------
   Paste your real IDs below, then redeploy. While an ID is empty
   (""), that tracker is NOT loaded: no extra requests, no console
   errors, nothing breaks. This file is loaded with `defer` on
   every page, so it never blocks rendering.

   GA4 MEASUREMENT ID — Google Analytics 4
     Where to get it: https://analytics.google.com
       Admin (gear icon) → Data Streams → your Web stream →
       "Measurement ID" — looks like G-ABC123DEF4.
     Paste it as:  ga4MeasurementId: "G-ABC123DEF4"

   FACEBOOK PIXEL ID — Meta Pixel (for future Facebook ads)
     Where to get it: https://business.facebook.com/events_manager
       → your Pixel → its numeric ID, e.g. 123456789012345.
     Paste it as:  facebookPixelId: "123456789012345"

   SOCIAL PROFILES — the site has NO social profiles yet. When the
   owner creates them, add the URLs to the footer and to the
   Organization schema's "sameAs" list in index.html. Do NOT invent
   URLs — only link profiles that actually exist.
   ============================================================ */
window.SITE_ANALYTICS = {
  ga4MeasurementId: "",   // <-- paste your GA4 ID here, e.g. "G-ABC123DEF4"
  facebookPixelId: ""     // <-- paste your Facebook Pixel ID here, e.g. "123456789012345"
};

(function () {
  var cfg = window.SITE_ANALYTICS || {};

  /* ---- Google Analytics 4 (loads only when an ID is set) ---- */
  if (cfg.ga4MeasurementId) {
    var gtagScript = document.createElement("script");
    gtagScript.async = true;
    gtagScript.src = "https://www.googletagmanager.com/gtag/js?id=" + encodeURIComponent(cfg.ga4MeasurementId);
    document.head.appendChild(gtagScript);
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    window.gtag("js", new Date());
    window.gtag("config", cfg.ga4MeasurementId);
  }

  /* ---- Facebook Pixel (loads only when an ID is set) ---- */
  if (cfg.facebookPixelId) {
    !(function (f, b, e, v, n, t, s) {
      if (f.fbq) return; n = f.fbq = function () {
        n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
      };
      if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = "2.0";
      n.queue = []; t = b.createElement(e); t.async = !0;
      t.src = v; s = b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t, s);
    })(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");
    window.fbq("init", cfg.facebookPixelId);
    window.fbq("track", "PageView");
  }
})();
