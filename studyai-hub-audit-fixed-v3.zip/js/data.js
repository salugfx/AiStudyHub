/* ============================================================
   SITE SETTINGS — change these to re-brand the whole site
   ============================================================ */
const SITE = {
  name: "StudyAI Hub",
  tagline: "Every AI tool a student needs — in one place",
  description: "A hand-reviewed directory of the best AI tools for students: writing, research, math, design, coding and more.",
  currency: "$",                 // change to "₹" if you prefer
  featuredPrice: "20",           // price for a 30-day featured listing
  whatsapp: "",                  // optional: your WhatsApp number e.g. "919876543210"
};

/* ============================================================
   LISTINGS — add / edit / remove entries here.
   pricing must be: "Free" | "Freemium" | "Paid"
   featured: true  => shows in the top Featured section (paid slot)
   NOTE: after adding tools, visitors see them automatically, but the
   pre-baked cards/JSON-LD inside index.html won't include them —
   ask ZCode to "re-bake index.html" for full SEO/link previews.
   ============================================================ */
const LISTINGS = [
  {
    name: "ChatGPT",
    url: "https://chatgpt.com",
    category: "Writing",
    pricing: "Freemium",
    featured: true,
    tagline: "Your AI study assistant for essays, summaries and doubt-solving",
    description: "The most popular AI chatbot in the world. Students use it to brainstorm essay outlines, summarize chapters, explain difficult concepts in simple words, and practice for interviews. The free tier is enough for most students.",
    tags: ["essays", "summarizer", "q&a", "chatbot"]
  },
  {
    name: "NotebookLM",
    url: "https://notebooklm.google.com",
    category: "Research",
    pricing: "Free",
    featured: true,
    tagline: "Upload your PDFs and chat with your own study material",
    description: "Made by Google. You upload your lecture notes, PDFs and slides, then ask questions answered only from YOUR material. It can even turn your notes into an audio podcast. Completely free.",
    tags: ["pdf chat", "notes", "google", "podcast"]
  },
  {
    name: "Notion",
    url: "https://www.notion.so",
    category: "Productivity",
    pricing: "Freemium",
    featured: true,
    tagline: "All-in-one notes, planner and wiki — free Pro plan for students",
    description: "The app serious students run their life on: class notes, assignment tracker, semester planner and group project wiki in one place. Verify with your student email and the paid plan is free.",
    tags: ["notes", "planner", "student email", "organisation"]
  },
  {
    name: "Perplexity",
    url: "https://www.perplexity.ai",
    category: "Research",
    pricing: "Freemium",
    tagline: "AI search engine that cites its sources — perfect for assignments",
    description: "Ask a question, get a direct answer with links to real sources you can cite in your assignment. Much better than regular search when you need facts fast.",
    tags: ["search", "citations", "research"]
  },
  {
    name: "Grammarly",
    url: "https://www.grammarly.com",
    category: "Writing",
    pricing: "Freemium",
    tagline: "Fix grammar and improve your essays as you type",
    description: "Catches grammar, spelling and clarity problems in everything you write — essays, emails, applications. The free browser extension is a must-have.",
    tags: ["grammar", "proofreading", "browser extension"]
  },
  {
    name: "Canva",
    url: "https://www.canva.com",
    category: "Design",
    pricing: "Freemium",
    tagline: "Design posters, presentations and resumes with AI Magic Studio",
    description: "Thousands of templates plus built-in AI tools for images and text. Canva for Education is free for students and teachers with a school email.",
    tags: ["posters", "resume", "presentations", "templates"]
  },
  {
    name: "Quizlet",
    url: "https://quizlet.com",
    category: "Study & Revision",
    pricing: "Freemium",
    tagline: "Flashcards and practice tests powered by AI",
    description: "Create flashcards once, then let AI turn them into practice tests, matching games and learn modes. Great for memorising heavy subjects before exams.",
    tags: ["flashcards", "exam prep", "memorise"]
  },
  {
    name: "Anki",
    url: "https://apps.ankiweb.net",
    category: "Study & Revision",
    pricing: "Free",
    tagline: "The classic spaced-repetition app that makes memory stick",
    description: "Free and open-source. It schedules your flashcards so you review exactly when you're about to forget — the scientifically proven way to remember for the long term.",
    tags: ["flashcards", "spaced repetition", "exam prep"]
  },
  {
    name: "Wolfram Alpha",
    url: "https://www.wolframalpha.com",
    category: "Math",
    pricing: "Freemium",
    tagline: "Step-by-step solutions for math and science problems",
    description: "A computation engine, not a search engine. Type any equation and it solves it — the paid step-by-step breakdowns are worth it during exam season.",
    tags: ["math solver", "steps", "science", "calculator"]
  },
  {
    name: "Photomath",
    url: "https://photomath.com",
    category: "Math",
    pricing: "Freemium",
    tagline: "Scan any equation and see it solved step by step",
    description: "Point your phone camera at a handwritten or printed math problem and get the full solution with explanations. The free version covers most school-level math.",
    tags: ["math", "camera", "homework"]
  },
  {
    name: "GitHub Copilot",
    url: "https://github.com/features/copilot",
    category: "Coding",
    pricing: "Free",
    tagline: "AI pair-programmer — completely FREE for verified students",
    description: "Autocompletes code and explains errors inside your editor. If you verify your student status with GitHub Education, you get it free — normally $10/month.",
    tags: ["code", "student free", "programming", "vs code"]
  },
  {
    name: "Gamma",
    url: "https://gamma.app",
    category: "Presentations",
    pricing: "Freemium",
    tagline: "Generate entire slide decks from one prompt",
    description: "Type your topic and Gamma writes the outline, content and design of a full presentation you can keep editing. Finishes in minutes what used to take all night.",
    tags: ["slides", "ppt", "ai generator"]
  },
  {
    name: "Zotero",
    url: "https://www.zotero.org",
    category: "Research",
    pricing: "Free",
    tagline: "Collect, organise and cite your research sources",
    description: "Free and open-source reference manager. Saves sources with one click and builds your bibliography automatically in APA, MLA and 9,000+ other styles.",
    tags: ["citations", "bibliography", "thesis", "references"]
  },
  {
    name: "DeepL",
    url: "https://www.deepl.com",
    category: "Writing",
    pricing: "Freemium",
    tagline: "The most accurate AI translator for 30+ languages",
    description: "Consistently more natural translations than competitors. Students use it for language homework, reading foreign papers and polishing translations.",
    tags: ["translation", "languages"]
  },
  {
    name: "Figma",
    url: "https://www.figma.com",
    category: "Design",
    pricing: "Freemium",
    tagline: "Collaborative design tool — free Professional plan for students",
    description: "The industry-standard design tool, in the browser. Verify as a student and get the paid plan free. Great for design students, portfolios and group projects.",
    tags: ["ui design", "student free", "portfolio"]
  }
];

/* Category list is generated from the listings above — no need to edit */
const CATEGORIES = ["All", ...[...new Set(LISTINGS.map(l => l.category))].sort()];
