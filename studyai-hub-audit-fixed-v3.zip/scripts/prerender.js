#!/usr/bin/env node
/**
 * StudyAI Hub — prerender script (audit fix, 22 Nov 2026).
 *
 * The homepage tool cards used to be rendered by JavaScript at runtime
 * (js/app.js), so crawlers and LLMs only saw ~45% of the page content.
 * This script bakes the cards from js/data.js into index.html as STATIC
 * HTML (featured strip + full directory, with full descriptions), so the
 * content is in the HTML Google and LLMs actually read. Since v3 it also
 * bakes the filter chips and the result count. js/app.js is progressive
 * enhancement now: on load it checks whether the static content already
 * matches the current (default) state and skips rebuilding it — it only
 * rebuilds when a filter/search actually changes what is shown.
 *
 * It also refreshes every tool page's SoftwareApplication JSON-LD
 * description from data.js, so the schema always matches the listing.
 *
 * Usage (from the site root, after editing js/data.js):
 *     node scripts/prerender.js
 * Then re-drag the folder to Netlify. No dependencies, Node 18+ is enough.
 */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const ROOT = path.join(__dirname, "..");

// ---- load data.js (it declares const SITE / LISTINGS / CATEGORIES) ----
// NOTE: `const` does not attach to the vm global object, so the export
// line is appended in the same script scope to read the values out.
const dataSrc = fs.readFileSync(path.join(ROOT, "js", "data.js"), "utf8")
  + "\n;module.exports = { SITE, LISTINGS, CATEGORIES };";
const sandbox = { module: { exports: {} }, console };
vm.createContext(sandbox);
vm.runInContext(dataSrc, sandbox);
const { SITE, LISTINGS, CATEGORIES } = sandbox.module.exports;

// ---- helpers (must match js/app.js exactly) ----
const AVATAR_HUES = [139, 236, 181, 58, 340, 219, 270, 27, 226, 18, 111, 183, 43, 128, 64];
function hashHue(name) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
  return h;
}
function avatarClass(name) {
  const h = hashHue(name);
  if (AVATAR_HUES.includes(h)) return `av-${h}`;
  let best = AVATAR_HUES[0];
  let bestD = 360;
  for (const p of AVATAR_HUES) {
    const d = Math.min(Math.abs(p - h), 360 - Math.abs(p - h));
    if (d < bestD) { bestD = d; best = p; }
  }
  return `av-${best}`;
}
const initials = (name) => name.split(/[\s-]/).map((w) => w[0]).join("").slice(0, 2).toUpperCase();
const slug = (name) => name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const pricingClass = { Free: "badge-free", Freemium: "badge-freemium", Paid: "badge-paid" };

function cardHTML(l, indent) {
  const ribbon = l.featured ? `\n${indent}  <span class="ribbon">FEATURED</span>` : "";
  const featCls = l.featured ? " featured-card" : "";
  return [
    `${indent}<article class="card${featCls}" data-name="${esc(l.name)}">${ribbon}`,
    `${indent}  <div class="card-top">`,
    `${indent}    <div class="avatar ${avatarClass(l.name)}">${initials(l.name)}</div>`,
    `${indent}    <h3>${esc(l.name)}</h3>`,
    `${indent}  </div>`,
    `${indent}  <p class="tagline">${esc(l.tagline)}</p>`,
    `${indent}  <p class="card-desc">${esc(l.description)}</p>`,
    `${indent}  <div class="card-foot">`,
    `${indent}    <span class="badge badge-cat">${esc(l.category)}</span>`,
    `${indent}    <span class="badge ${pricingClass[l.pricing] || "badge-paid"}">${esc(l.pricing)}</span>`,
    `${indent}    <span class="visit">Visit ↗</span> <a class="details-link" href="tools/${slug(l.name)}.html">Details →</a>`,
    `${indent}  </div>`,
    `${indent}</article>`,
  ].join("\n");
}

function replaceBetween(html, start, end, body) {
  const i = html.indexOf(start);
  const j = html.indexOf(end);
  if (i === -1 || j === -1 || j < i) throw new Error(`markers not found: ${start}`);
  const before = html.slice(0, i + start.length);
  const after = html.slice(j);
  return `${before}\n${body}\n        ${after}`;
}

// ---- 1. index.html grids ----
const indexPath = path.join(ROOT, "index.html");
let index = fs.readFileSync(indexPath, "utf8");
const featured = LISTINGS.filter((l) => l.featured);
index = replaceBetween(
  index,
  "<!-- PRERENDER:FEATURED:START -->",
  "<!-- PRERENDER:FEATURED:END -->",
  featured.map((l) => cardHTML(l, "        ")).join("\n")
);
index = replaceBetween(
  index,
  "<!-- PRERENDER:LISTINGS:START -->",
  "<!-- PRERENDER:LISTINGS:END -->",
  LISTINGS.map((l) => cardHTML(l, "        ")).join("\n")
);

// ---- 1b. filter chips + result count (v3) ----
// Same templates as js/app.js renderChips(), default state (All / All),
// so the static chips are byte-identical to what the JS would build.
const catChips = CATEGORIES.map((c) => {
  const n = c === "All" ? LISTINGS.length : LISTINGS.filter((l) => l.category === c).length;
  return `<button class="chip ${c === "All" ? "active" : ""}" data-cat="${c}">${c}<span class="count">${n}</span></button>`;
}).join("");
const priceChips = ["All", "Free", "Freemium", "Paid"]
  .map((p) => `<button class="chip ${p === "All" ? "active" : ""}" data-price="${p}">${p === "All" ? "Any pricing" : p}</button>`)
  .join("");
index = replaceBetween(index, "<!-- PRERENDER:CHIPS-CAT:START -->", "<!-- PRERENDER:CHIPS-CAT:END -->", catChips);
index = replaceBetween(index, "<!-- PRERENDER:CHIPS-PRICE:START -->", "<!-- PRERENDER:CHIPS-PRICE:END -->", priceChips);
index = index.replace(
  /<p id="result-count" class="result-info">.*?<\/p>/,
  `<p id="result-count" class="result-info">Showing <b>${LISTINGS.length}</b> of <b>${LISTINGS.length}</b> tools</p>`
);
fs.writeFileSync(indexPath, index);
console.log(`index.html: ${featured.length} featured cards + ${LISTINGS.length} directory cards baked in`);
console.log(`index.html: ${CATEGORIES.length} category chips + 4 price chips + result count baked in`);

// ---- 2. tool pages: SoftwareApplication description from data.js ----
let updated = 0;
for (const l of LISTINGS) {
  const file = path.join(ROOT, "tools", `${slug(l.name)}.html`);
  if (!fs.existsSync(file)) { console.warn(`missing tool page: ${file}`); continue; }
  let html = fs.readFileSync(file, "utf8");
  const m = html.match(/<script type="application\/ld\+json">(\{.*\})<\/script>/);
  if (!m) { console.warn(`no JSON-LD in ${file}`); continue; }
  const schema = JSON.parse(m[1]);
  if (schema["@type"] !== "SoftwareApplication") { console.warn(`unexpected schema in ${file}`); continue; }
  schema.description = l.description;
  if (l.pricing === "Free" && !schema.offers) {
    schema.offers = { "@type": "Offer", price: "0", priceCurrency: "USD" };
  }
  html = html.replace(m[1], JSON.stringify(schema));
  fs.writeFileSync(file, html);
  updated++;
}
console.log(`tool pages: ${updated} SoftwareApplication descriptions refreshed from data.js`);
console.log(`site: ${SITE.name} — featured $${SITE.featuredPrice}/30 days — done.`);
