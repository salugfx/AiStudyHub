# 🎓 StudyAI Hub — your free directory website

A complete, working directory website ("AI tools for students"). No coding needed to run it.
Everything about the site (name, price, listings) is edited in **one file: `js/data.js`**.

---

## 💰 What it costs

| What | Cost |
|---|---|
| This website (files) | **$0** — already built |
| Hosting on Netlify (free plan) | **$0 forever** |
| Your web address `yourname.netlify.app` + HTTPS lock | **$0** |
| Submission form (Formspree free plan) | **$0** (up to 50 submissions/month) |
| Taking payments (PayPal.me / UPI link) | **$0** — no monthly fee |
| Custom domain like `studyaihub.com` (OPTIONAL, later) | ~$10–15/year |

**Total to launch: $0.** The only paid thing ever is a custom domain, and only when you want it.

---

## 🚀 Put it online FREE (10 minutes)

### Step 1 — Drag & drop to Netlify
1. Go to **https://app.netlify.com/drop** (sign up free with Gmail first)
2. Drag this whole `ai-tools-directory` folder onto the page
3. Done — your site is LIVE at a free address like `random-name-123.netlify.app`

### Step 2 — Rename your free address
1. In Netlify: **Site settings → Change site name**
2. Pick something like `studyaihub` → your address becomes `studyaihub.netlify.app`

### Step 3 — Connect the submission form (2 minutes)
1. Sign up free at **https://formspree.io** → Create form
2. Copy your form ID (looks like `xqkrgzzz`)
3. Open `submit.html`, find `YOUR_FORM_ID` in the form action, replace it with your ID
4. Re-upload (drag the folder to Netlify again — it updates instantly)

Now every submission lands in your email inbox. Free plan = 50/month, plenty to start.

### Step 4 — Tell Google you exist (5 minutes)
1. Go to **https://search.google.com/search-console** (free)
2. Add your `yourname.netlify.app` address
3. Submit the sitemap: just enter `/` (homepage) — your JSON-LD structured data is already built in

---

## ✏️ How to edit the site

Open **`js/data.js`** in any text editor (Notepad works):

- **Change site name / price / email** → edit the `SITE` block at the top
- **Add a tool** → copy one `{ ... }` block, paste it, change the details
- **Mark a tool FEATURED (paid slot)** → set `featured: true`
- **Remove a tool** → delete its block

Then re-drag the folder to Netlify. Live in seconds.

---

## 📈 How you actually earn (3 streams)

| Stream | How | Realistic start |
|---|---|---|
| **1. Featured listings** | Tool makers pay $20/30 days for homepage top slot | Once you have traffic |
| **2. Sponsor banner** | One company pays $25–120/month to banner the site | After 5–10k visits/month |
| **3. Affiliate links** | Many tools pay you when users sign up (search "tool name + affiliate program") | From day 1 |

**Payments with $0 setup:** put your PayPal.me link (or UPI id if you're in India) in the reply email. When someone
requests FEATURED, they pay first, you set `featured: true`. No Stripe, no gateway needed.

---

## ⚠️ Honest growth plan (money follows traffic)

A directory earns when it has visitors. Expect **4–12 weeks of consistent effort** before income:

- **Week 1–2:** share in student WhatsApp/Telegram/Discord groups, Reddit (r/college, r/study), Instagram
- **Week 2–8:** add 3–5 new listings per week (more pages = more Google traffic)
- **Week 4+:** once you get ~1,000 visits/month, start emailing small AI-tool startups offering featured slots
  (search ProductHunt for new student tools — they NEED visibility and will pay for it)

---

## 🔧 SEO audit fix (22 Nov 2026) — what changed

The site was audited in November 2026 (overall grade **B**). This release
fixes everything code can fix — full list in `CHANGES.md` and
`FIX-REPORT.md` (in the zip's parent folder). Highlights:

- **Primary host is `https://bestaitoolsforstudent.netlify.app`.**
  `aitools-for-students.netlify.app` is a duplicate deployment — set it to
  301-redirect to the primary host in the Netlify dashboard (or delete it).
- **After editing `js/data.js`, re-bake the homepage:** run
  `node scripts/prerender.js` (no dependencies). It writes the 15 tool
  cards into `index.html` as static HTML and refreshes the tool pages'
  schema descriptions. Then re-drag the folder to Netlify.
- **Analytics:** paste your real IDs into `js/analytics.js`
  (`ga4MeasurementId` for Google Analytics 4, `facebookPixelId` for the
  Meta Pixel). Both are empty by default, so nothing loads until you add
  them. The site has no social profiles yet — create them first, then
  link them in the footer and the Organization schema.
- **Still needs you (no code can do these):** backlinks from other sites,
  a Google Business Profile, DMARC/SPF records (needs a custom domain —
  impossible on a `*.netlify.app` address).

## 🔁 Want a different niche?

This whole site is niche-independent. Tell ZCode your niche
("tutors in Mumbai", "AI tools for doctors", "wedding photographers in Delhi")
and it can be re-skinned — new name, new categories, new listings — in minutes.
